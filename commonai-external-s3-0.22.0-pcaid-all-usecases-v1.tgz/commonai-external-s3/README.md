# CommonAI With External S3

This standalone chart leaves the original `commonai` chart unchanged.

Bundled MinIO is disabled with `minio.enabled: false`. Object storage uses:

```text
http://local-s3-service.ezdata-system.svc.cluster.local:30000
```

The orchestrator and worker receive the endpoint without the URL scheme, as
expected by their MinIO-compatible clients. The connection uses HTTP, not TLS.

Before installation, configure these values for the external S3 service:

- `minio.credentials.rootUser`: S3 access key, replacing the inherited default.
- `minio.credentials.rootPassword`: S3 secret key, replacing the inherited default.
- `minio.bucket`: existing bucket name (default: `data-copilot`).

The chart does not create the external bucket. Ensure the credentials permit
access to it and that pods can reach the endpoint in `ezdata-system`.

Install from the workspace root after configuring the values:

```sh
helm upgrade --install commonai-external-s3 ./commonai-external-s3
```